// backend/models/DeliveryMan.js
const { DataTypes, Model } = require('sequelize');
const bcrypt = require('bcryptjs');
const sequelize = require('../config/database'); // Import Sequelize instance
const Order = require('./Order'); // Assuming an Order model exists

class DeliveryMan extends Model {
  async comparePassword(plainPassword) {
    return bcrypt.compare(plainPassword, this.password);
  }
}

DeliveryMan.init(
  {
    name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    email: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
    },
    password: {
      type: DataTypes.STRING,
      allowNull: false,
    },
  },
  {
    sequelize, // Pass the Sequelize instance
    modelName: 'DeliveryMan', // Name of the table
    timestamps: true,
    hooks: {
      beforeCreate: async (deliveryMan) => {
        const salt = await bcrypt.genSalt(10);
        deliveryMan.password = await bcrypt.hash(deliveryMan.password, salt);
      },
      beforeUpdate: async (deliveryMan) => {
        if (deliveryMan.changed('password')) {
          const salt = await bcrypt.genSalt(10);
          deliveryMan.password = await bcrypt.hash(deliveryMan.password, salt);
        }
      },
    },
  }
);

// Define association between DeliveryMan and Order
DeliveryMan.hasMany(Order, {
  foreignKey: 'deliveryManId', // Foreign key in the Order table
  as: 'assignedOrders', // Alias for the association
});
Order.belongsTo(DeliveryMan, {
  foreignKey: 'deliveryManId', // Foreign key in the Order table
  as: 'deliveryMan', // Alias for the association
});

module.exports = DeliveryMan;
