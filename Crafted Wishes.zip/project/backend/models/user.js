import { DataTypes } from 'sequelize';
import sequelize from '../config/db.js'; // Adjust the path to your db.js file

const User = sequelize.define('User', {
    username: {
        type: DataTypes.STRING,
        allowNull: false
    },
    email: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true
    },
    password: {
        type: DataTypes.STRING,
        allowNull: false
    },
    role: {
        type: DataTypes.STRING,
        allowNull: false
    },
    phonenumber: {
        type: DataTypes.STRING(10),
        allowNull: true
    },
    useraddress: {
        type: DataTypes.STRING,
        allowNull: true
    }
});

export default User;