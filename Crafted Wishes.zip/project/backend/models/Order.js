// backend/models/Order.js
const { DataTypes, Model } = require('sequelize');
const sequelize = require('../config/database'); // Import Sequelize instance
const DeliveryMan = require('./DeliveryMan'); // Import the DeliveryMan model

class Order extends Model {}

Order.init(
  {
    product: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    quantity: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    status: {
      type: DataTypes.STRING,
      defaultValue: 'Pending', // Default status
    },
  },
  {
    sequelize, // Pass the Sequelize instance
    modelName: 'Order', // Name of the table
    timestamps: true,
  }
);

// Define association between Order and DeliveryMan
Order.belongsTo(DeliveryMan, {
  foreignKey: 'assignedTo', // Foreign key in the Order table
  as: 'deliveryMan', // Alias for the association
});
DeliveryMan.hasMany(Order, {
  foreignKey: 'assignedTo', // Foreign key in the Order table
  as: 'orders', // Alias for the association
});

module.exports = Order;
