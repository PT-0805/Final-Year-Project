const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
const port = 3307;

app.use(cors());
app.use(bodyParser.json());

// Sample signup route
app.post('/routes/signup', (req, res) => {
    const { username, email, password, role, phonenumber, useraddress } = req.body;

    if (!username || !email || !password || !role || !phonenumber || !useraddress) {
        return res.status(400).json({ error: 'All fields are required' });
    }

    // Normally, you would save the user to a database here.
    console.log('User registered:', req.body);
    res.status(201).json({ message: 'User signed up successfully!' });
});

app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});
