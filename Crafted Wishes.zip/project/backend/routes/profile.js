import express from 'express';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import User from '../models/user.js';

const router = express.Router();

// Middleware for verifying token
const authenticateToken_Old = (req, res, next) => {
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) return res.status(401).json({ error: 'Unauthorized: No token provided' });

    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        req.userId = decoded.userId;
        req.role = decoded.role;
        next();
    } catch (error) {
        return res.status(403).json({ error: 'Forbidden: Invalid token' });
    }
};

const authenticateToken = (req, res, next) => {
    // console.log('Hi !')
    const authHeader = req.headers.authorization;  // ✅ Get Authorization header
    console.log(authHeader)
    if (!authHeader) return res.status(403).json({ error: 'Forbidden: No token provided' });

    const token = authHeader.split(' ')[1]; // ✅ Extract Bearer token correctly
    if (!token) return res.status(403).json({ error: 'Forbidden: Invalid token format' });

    jwt.verify(token, 'your_secret_key', (err, decoded) => {
        if (err) return res.status(403).json({ error: 'Forbidden: Invalid token' });

        req.userId = decoded.userId;  // ✅ Attach userId to request
        next();
    });
};


// Get user profile
router.get('/', authenticateToken, async (req, res) => {
    try {
        console.log("in API/Profile");
        const user = await User.findByPk(req.userId);
        if (!user) return res.status(404).json({ error: 'User not found' });

        res.json({
            userId: user.id,
            username: user.username,
            email: user.email,
            role: user.role,
            phonenumber: user.phonenumber,
            useraddress: user.useraddress
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Update user profile
router.put('/update', authenticateToken, async (req, res) => {
    // console.log('hi in update profile'); // ✅ Check if this appears in logs
    try {
        const { username, email, password, role, phonenumber, useraddress } = req.body;
        console.log('Received update data:', req.body); // ✅ Log request data


        const user = await User.findByPk(req.userId);
        if (!user) return res.status(404).json({ error: 'User not found' });

        user.username = username;
        user.email = email;
        // if (password) user.password = await bcrypt.hash(password, 10);
        console.log("Password before hashing:", password);
        if (password && password.trim() !== "") {
            console.log("Hashing password...");
            user.password = await bcrypt.hash(password, 10);
        }
        user.role = role;
        user.phonenumber = phonenumber;
        user.useraddress = useraddress;

        await user.save();
        res.json({ message: 'Profile updated successfully' });
    } catch (error) {
        console.error('Profile Update Error:', error); // ✅ Log actual error
        res.status(500).json({ error: error.message });
    }
});

export default router;
