import express from 'express';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import User from '../models/user.js';

const router = express.Router();
const SECRET_KEY = 'your_secret_key'; // Change this to a secure key

// Login Route - Authenticate and Redirect Based on Role
router.post('/login', async (req, res) => {
    try {
        const { email, password, role } = req.body;
        // console.log("Received login request:", { email, role });

        if (!email || !password || !role) {
            // console.log("Missing fields in request!");
            return res.status(400).json({ error: 'Email, password, and role are required.' });
        }

        const user = await User.findOne({ where: { email } });
        if (!user) {
            // console.log("User not found for email:", email);
            return res.status(401).json({ error: 'Invalid email or password.' });
        }
        console.log("User found:", user.id, "Role:", user.role);

        if (user.role !== role) {
            // console.log("Role mismatch: Expected", user.role, "but received", role);
            return res.status(403).json({ error: 'Unauthorized: Incorrect role selected.' });
        }

        const isPasswordValid = await bcrypt.compare(password, user.password);
        if (!isPasswordValid) {
            // console.log("Password does not match for user:", user.id);
            return res.status(401).json({ error: 'Invalid email or password.' });
        }
        // console.log("User authenticated successfully!");

        const token = jwt.sign({ userId: user.id, role: user.role }, SECRET_KEY, { expiresIn: '1h' });
        // console.log("Generated Token:", token);

        res.cookie('authToken', token, { httpOnly: true, secure: true });

        const roleRedirects = {
            admin: '/dashboard/Admin/profile.html', // ✅ Ensures admin is redirected here
            user: '/dashboard/User/profile.html'
        };
        const redirectUrl = roleRedirects[user.role] || '/profile.html';        
        // console.log("Sending response:", { redirectUrl, token });

        res.status(200).json({ redirectUrl, token, email });

    } catch (error) {
        console.error('Login Error:', error);
        res.status(500).json({ error: 'An error occurred while logging in. Please try again.' });
    }
});

export default router;
