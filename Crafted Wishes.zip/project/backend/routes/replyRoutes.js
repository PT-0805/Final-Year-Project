import express from 'express';
const router = express.Router();
import Reply from '../models/Reply.js';
import Query from '../models/Query.js';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import User from '../models/user.js';

const authenticateToken = (req, res, next) => {
    //console.log('Hi !')
    const authHeader = req.headers.authorization;  // ✅ Get Authorization header
    console.log(authHeader)
    if (!authHeader) return res.status(403).json({ error: 'Forbidden: No token provided' });

    const token = authHeader.split(' ')[1]; // ✅ Extract Bearer token correctly
    if (!token) return res.status(403).json({ error: 'Forbidden: Invalid token format' });

    jwt.verify(token, 'your_secret_key', (err, decoded) => {
        if (err) return res.status(403).json({ error: 'Forbidden: Invalid token' });

        req.userId = decoded.userId;  // ✅ Attach userId to request
        req.userRole = decoded.role; // ✅ Fix: Ensure user role is set
        next();
    });
};

// 📌 Admin: Add a reply (Requires Authentication)
router.post("/add", authenticateToken, async (req, res) => {
    try {
        console.log("User Role:", req.userRole); // ✅ Debugging

        if (req.userRole !== "admin") { // ✅ Fix: Correct role check
            return res.status(403).json({ message: "Access denied." });
        }

        const { query_id, reply_text } = req.body;
        const admin_id = req.userId; // ✅ Fix: Correct user ID

        // Check if query exists
        const query = await Query.findByPk(query_id);
        if (!query) {
            return res.status(404).json({ error: "Query not found" });
        }

        // Create reply
        const reply = await Reply.create({ query_id, admin_id, reply_text });

        res.status(201).json({ message: "Reply added successfully", reply });
    } catch (error) {
        console.error("❌ Error adding reply:", error);
        res.status(500).json({ error: error.message });
    }
});


// 📌 Get replies (Users see their own, Admin sees all)
router.get("/query/:queryId", authenticateToken, async (req, res) => {
    try {
        const { queryId } = req.params;

        console.log("Fetching replies for query ID:", queryId);

        const replies = await Reply.findAll({
            where: { query_id: queryId },
            order: [["created_at", "ASC"]]
        });

        if (!Array.isArray(replies)) {
            return res.status(200).json([]); // ✅ Fix: Ensure an empty array is returned
        }

        res.status(200).json(replies);
    } catch (error) {
        console.error("❌ Error fetching replies:", error);
        res.status(500).json({ error: "Internal Server Error" });
    }
});


// 📌 Admin: Delete a reply (Requires Authentication)
router.delete("/delete/:id", authenticateToken, async (req, res) => {
    try {
        if (req.user.role !== "admin") {
            return res.status(403).json({ message: "Access denied." });
        }

        const { id } = req.params;
        const reply = await Reply.findByPk(id);

        if (!reply) {
            return res.status(404).json({ error: "Reply not found" });
        }

        await reply.destroy();
        res.json({ message: "Reply deleted successfully" });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

export default router;

