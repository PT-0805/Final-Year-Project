import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import cookieParser from 'cookie-parser';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import sequelize from './config/db.js'; // Adjust the path to your db.js file
import User from './models/user.js'; // Ensure you have a User model
import Query from './models/Query.js'; // Query Model
import Reply from './models/Reply.js'; // Reply Model
// import userRoutes from './routes/user.js';
import userRoutes from './routes/login.js';
import newuserRoutes from './routes/user.js';
import profileRoutes from './routes/profile.js';
import cartRoutes from './routes/cart.js';
import wishlistRoutes from './routes/wishlist.js';
import productRoutes from './routes/products.js';
import queryRoutes from './routes/queryRoutes.js'; // Query Routes
import replyRoutes from './routes/replyRoutes.js'; // Reply Routes


const PORT = 3307;
const SECRET_KEY = 'your_secret_key'; // Change this to a secure key

// Middleware to parse JSON data and use cookies
const app = express();

//app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(cookieParser());

// Serve static frontend files
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
app.use(express.static(path.join(__dirname, "../frontend")));

// Serve the index.html file for the root URL
app.get("/", (req, res) => {
    const indexPath = path.join(__dirname, "../frontend", "index.html");
    res.sendFile(indexPath, (err) => {
        if (err) {
            console.error("Error sending index.html:", err);
            res.status(500).send("Error sending file");
        }
    });
});

// Use routes

app.use('/user', userRoutes);
app.use('/user', newuserRoutes);
app.use('/profile', profileRoutes);
app.use("/cart", cartRoutes);
app.use("/wishlist", wishlistRoutes);
app.use("/product", productRoutes);
app.use("/api/queries", queryRoutes);
app.use("/api/replies", replyRoutes);

// Cache control settings
app.use((req, res, next) => {
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');
    next();
});

// Test the database connection
sequelize.authenticate()
    .then(() => console.log('Database connected...'))
    .catch(err => console.error('Unable to connect to the database:', err));

// Sync the models with the database
sequelize.sync()
    .then(() => console.log('Models synchronized with the database.'))
    .catch(err => console.error('Error synchronizing models with the database:', err));

//Users Route(Admin Only)    
app.get("/api/Users", async (req, res) => {
    try {
        let { page, limit } = req.query;
        page = parseInt(page) || 1;
        limit = parseInt(limit) || 10;
        const offset = (page - 1) * limit;

        // Fetch total count and paginated data
        const { count, rows: users } = await User.findAndCountAll({
            attributes: ["id", "username", "email", "role", "phonenumber", "useraddress"],
            limit,
            offset
        });

        res.json({
            totalUsers: count,
            totalPages: Math.ceil(count / limit),
            currentPage: page,
            users
        });
    } catch (error) {
        console.error("Error fetching users:", error);
        res.status(500).json({ error: "Internal Server Error" });
    }
});



// Profile route
app.get('/api/profile', async (req, res) => {
    try {

        res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate");
        res.setHeader("Pragma", "no-cache");
        res.setHeader("Expires", "0");

        const token = req.cookies.authToken;
        if (!token) {
            return res.status(401).json({ error: "Unauthorized: No token found" });
        }

        const decoded = jwt.verify(token, SECRET_KEY);
        const user = await User.findByPk(decoded.userId, { attributes: { exclude: ['password'] } });

        if (!user) {
            return res.status(404).json({ error: "User not found" });
        }

        res.json({
            username: user.username,
            email: user.email,
            phonenumber: user.phonenumber,
            useraddress: user.useraddress,            
            role: user.role
        });

    } catch (error) {
        console.error("Profile Fetch Error:", error);
        res.status(500).json({ error: "Internal Server Error" });
    }
});

// Login route with role-based redirection
// app.post('/user/login', async (req, res) => {
//     try {
//         const { email, password, role } = req.body;
//         console.log("in app.js Received login request:", { email, role });

//         // Find user by email and role
//         const user = await User.findOne({ where: { email, role } });

//         if (!user) {
//             return res.status(401).json({ error: 'User not found' });
//         }

//         // Check password
//         const isPasswordValid = await bcrypt.compare(password, user.password);
//         if (!isPasswordValid) {
//             return res.status(401).json({ error: 'Invalid credentials' });
//         }

//         // Generate JWT token
//         const token = jwt.sign({ id: user.id, role: user.role }, 'your_secret_key', { expiresIn: '1h' });

//         // Determine redirect URL based on role
//         let redirectUrl = role === 'admin' ? '/dashboard/admin/index2.html' : '/profile.html';

//         // Send response
//         res.json({ token, redirectUrl });

//     } catch (error) {
//         console.error('Login error:', error);
//         res.status(500).json({ error: 'Internal server error' });
//     }
// });


// Redirect users to their respective dashboards
app.get('/:role-dashboard.html', (req, res) => {
    const filePath = path.join(__dirname, "../frontend", `${req.params.role}-dashboard.html`);
    res.sendFile(filePath, (err) => {
        if (err) {
            console.error(`Error sending ${req.params.role}-dashboard.html:`, err);
            res.status(500).send("Error sending file");
        }
    });
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
