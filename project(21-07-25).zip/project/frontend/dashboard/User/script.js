function redirectToRolePage() {
    var role = document.getElementById("role").value;
    if (role) {
        window.location.href = role;
    }
}
