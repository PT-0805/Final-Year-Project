// backend/models/Dealer.js
const { DataTypes, Model } = require('sequelize');
const bcrypt = require('bcryptjs');
const sequelize = require('../config/database'); // Import the Sequelize instance
const Product = require('./Product'); // Assuming a Product model exists

class Dealer extends Model {
  async comparePassword(plainPassword) {
    return bcrypt.compare(plainPassword, this.password);
  }
}

Dealer.init(
  {
    name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    email: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
    },
    password: {
      type: DataTypes.STRING,
      allowNull: false,
    },
  },
  {
    sequelize, // Pass the Sequelize instance
    modelName: 'Dealer', // Table name in the database
    timestamps: true,
    hooks: {
      beforeCreate: async (dealer) => {
        const salt = await bcrypt.genSalt(10);
        dealer.password = await bcrypt.hash(dealer.password, salt);
      },
      beforeUpdate: async (dealer) => {
        if (dealer.changed('password')) {
          const salt = await bcrypt.genSalt(10);
          dealer.password = await bcrypt.hash(dealer.password, salt);
        }
      },
    },
  }
);

// Define association between Dealer and Product
Dealer.hasMany(Product, {
  foreignKey: 'dealerId', // Foreign key in the Product table
  as: 'products', // Alias for the association
});
Product.belongsTo(Dealer, {
  foreignKey: 'dealerId', // Foreign key in the Product table
  as: 'dealer', // Alias for the association
});

module.exports = Dealer;
