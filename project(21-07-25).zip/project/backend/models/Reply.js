import { DataTypes } from 'sequelize';
import sequelize from '../config/db.js'; // Adjust the path to your db.js file

const Reply = sequelize.define("Reply", {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
    },
    query_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    admin_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    reply_text: {
        type: DataTypes.TEXT,
        allowNull: false,
    },
    created_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
    },
}, {
    timestamps: false,
});

export default Reply;
