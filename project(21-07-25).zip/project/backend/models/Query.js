import { DataTypes } from 'sequelize';
import sequelize from '../config/db.js'; // Adjust the path to your db.js file

const Query = sequelize.define("Query", {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
    },
    user_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    query_text: {
        type: DataTypes.TEXT,
        allowNull: false,
    },
    status: {
        type: DataTypes.ENUM("Open", "In-progress", "Closed"),
        defaultValue: "Open",
    },
    created_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW,
    },
}, {
    timestamps: false,
});

export default Query;
