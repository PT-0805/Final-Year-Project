const db = require('../config/db');

const query = 'SELECT username, login_time FROM login_details ORDER BY login_time DESC';

db.query(query, (err, results) => {
    if (err) {
        console.error('Error retrieving login details:', err);
        return;
    }
    console.log('Login details:', results);
    db.end();
});
