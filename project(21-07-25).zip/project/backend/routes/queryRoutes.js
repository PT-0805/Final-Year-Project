import express from 'express';
const router = express.Router();
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import User from '../models/user.js';
import { Op } from "sequelize";
//import auth from "../middleware/auth.js";
import Query from '../models/Query.js';
import Reply from '../models/Reply.js';


const authenticateToken = (req, res, next) => {
    //console.log('Hi !')
    const authHeader = req.headers.authorization;  // ✅ Get Authorization header
    console.log("Auth Header : ", authHeader)
    if (!authHeader) return res.status(403).json({ error: 'Forbidden: No token provided' });

    const token = authHeader.split(' ')[1]; // ✅ Extract Bearer token correctly
    if (!token) return res.status(403).json({ error: 'Forbidden: Invalid token format' });

    jwt.verify(token, 'your_secret_key', (err, decoded) => {
        if (err) return res.status(403).json({ error: 'Forbidden: Invalid token' });

        req.userId = decoded.userId;  // ✅ Attach userId to request
        req.userRole = decoded.role; // ✅ Fix: Ensure user role is set
        next();
    });
};

// 📌 **User: Submit a Query**
router.post("/submit", authenticateToken, async (req, res) => {
    try {
        console.log("Received Query Submission:", req.body);
        const { query_text } = req.body;
        const user_id = req.userId; // ✅ FIXED: Use `req.userId`

        if (!query_text) {
            return res.status(400).json({ error: "Query text is required." });
        }

        const query = await Query.create({ user_id, query_text, status: "Open" });
        res.status(201).json({ message: "Query submitted successfully", query });
    } catch (error) {
        console.error("Error submitting query:", error);
        res.status(500).json({ error: "Internal Server Error" });
    }
});

router.get("/all", authenticateToken, async (req, res) => {
    try {
        console.log("Fetching queries for user ID:", req.userId, "Role:", req.userRole);

        const { page = 1, limit = 10, search = "" } = req.query;
        const offset = (page - 1) * limit;

        let whereCondition = { query_text: { [Op.like]: `%${search}%` } };

        // ✅ Fix: Only filter by `user_id` for non-admins
        if (req.userRole !== "admin") {
            whereCondition.user_id = req.userId;
        }

        console.log("Query Condition:", whereCondition);

        const queries = await Query.findAndCountAll({
            where: whereCondition,
            limit: parseInt(limit),
            offset: parseInt(offset),
            order: [["created_at", "DESC"]],
        });

        if (!queries || !queries.rows || !Array.isArray(queries.rows)) {
            return res.status(200).json({ total: 0, queries: [] }); // ✅ Fix: Always return array
        }

        res.status(200).json({ total: queries.count, queries: queries.rows });
    } catch (error) {
        console.error("❌ Error fetching queries:", error);
        res.status(500).json({ error: "Internal Server Error" });
    }
});


// 📌 Admin: Update query status (Requires Authentication)
router.put("/update-status/:id", authenticateToken, async (req, res) => {
    try {
        console.log("Updating status - User Role:", req.userRole); // ✅ Debugging

        if (req.userRole !== "admin") { // ✅ Ensure only admins can update status
            return res.status(403).json({ message: "Access denied." });
        }

        const { id } = req.params;
        const { status } = req.body;

        const query = await Query.findByPk(id);
        if (!query) {
            return res.status(404).json({ error: "Query not found" });
        }

        await query.update({ status });

        res.json({ message: "Query status updated successfully" });
    } catch (error) {
        console.error("❌ Error updating query status:", error);
        res.status(500).json({ error: error.message });
    }
});


export default router;
