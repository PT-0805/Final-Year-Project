import express from 'express';
const router = express.Router();

// Simulated database or product data
const products = [
    { id: '1', title: 'Personalized Mug', description: 'Enjoy your morning coffee in a mug with your name on it.', price: 120, image: '/images/mug.jpg', specifications: { material: 'Ceramic', size: '350ml', care: 'Hand wash only' } },
    // Add more products as needed
];

// Fetch product details 
router.get('/products.', (req, res) => {
    const products = products.findAll();
    if (products) {
        res.json(products);
    } else {
        res.status(404).json({ message: 'No products found' });
    }
});

const reviews = {}; // Example: { "1": [{ username: "John", reviewText: "Great mug!" }] }

// Fetch product details by ID
router.get('/:productId', (req, res) => {
    const product = products.find(p => p.id === req.params.productId);
    if (product) {
        res.json(product);
    } else {
        res.status(404).json({ message: 'Product not found' });
    }
});

// Fetch reviews for a product
router.get('/:productId/reviews', (req, res) => {
    const productReviews = reviews[req.params.productId] || [];
    res.json(productReviews);
});

// Submit a review for a product
router.post('/:productId/reviews', (req, res) => {
    const { username, reviewText } = req.body;
    const productId = req.params.productId;

    if (!username || !reviewText) {
        return res.status(400).json({ message: 'Username and review text are required' });
    }

    if (!reviews[productId]) {
        reviews[productId] = [];
    }
    reviews[productId].push({ username, reviewText });

    res.status(201).json({ message: 'Review submitted successfully' });
});

export default router;
