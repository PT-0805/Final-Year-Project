import express from 'express';
import db from '../config/db.js';

const router = express.Router();

// Add to Cart
router.post('/', (req, res) => {
    const { userId, product_name, description, price, image, quantity } = req.body;

    // First, check if the product exists in the database
    const productQuery = 'SELECT product_id FROM products WHERE product_name = ? LIMIT 1';

    db.query(productQuery, [product_name], (err, results) => {
        if (err) return res.status(500).json({ error: err.message });

        if (results.length === 0) {
            return res.status(404).json({ message: 'Product not found' });
        }

        const product_id = results[0].product_id;

        // Insert into cart
        const cartQuery = 'INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, ?)';
        db.query(cartQuery, [userId, product_id, quantity], (err, result) => {
            if (err) return res.status(500).json({ error: err.message });
            res.status(201).json({ message: 'Item added to cart' });
        });
    });
});


// View Cart for a specific user
router.get('/:userId', (req, res) => {
    console.log("Cart OR Order");
    const userId = parseInt(req.params.userId, 10); // Ensure it's a number

    if (isNaN(userId)) {
        return res.status(400).json({ error: "Invalid user ID" });
    }

    const query = `
        SELECT cart.cart_id, products.product_name, cart.quantity, products.price, products.image
        FROM cart
        JOIN products ON cart.product_id = products.product_id
        WHERE cart.user_id = ?`;

    db.query(query, [userId], (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.status(200).json({ cart: results });
    });
});


// Update Cart Item Quantity
router.put('/:cartId', (req, res) => {
    const { cartId } = req.params;
    const { quantity } = req.body;

    if (quantity < 1) {
        return res.status(400).json({ message: 'Quantity must be at least 1' });
    }

    const query = 'UPDATE cart SET quantity = ? WHERE cart_id = ?';
    db.query(query, [quantity, cartId], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.status(200).json({ message: 'Cart updated successfully' });
    });
});

// Remove Item from Cart
router.delete('/:cartId', (req, res) => {
    const { cartId } = req.params;

    const query = 'DELETE FROM cart WHERE cart_id = ?';
    db.query(query, [cartId], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.status(200).json({ message: 'Item removed from cart' });
    });
});

export default router;
