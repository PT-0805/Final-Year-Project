import express from 'express';
import bcrypt from 'bcrypt';
import User from '../models/user.js'; // Adjust the path to your User model

const router = express.Router();

router.post('/', async (req, res) => {
    try {
        const { username, password } = req.body;
        const user = await User.findOne({ where: { username } });
        console.log(user)
        // if (!user) {
        //     return res.status(401).json({ error: 'Invalid username or password' });
        // }
        console.log(password,user.password)
        if(password == user.password){
            var isPasswordValid = true;

        }
        else{
            var isPasswordValid = false;

        }
        console.log(isPasswordValid)

        if (!isPasswordValid) {
            return res.status(401).json({ error: 'Invalid username or password' });
        }

        const loginTime = new Date();
        res.status(200).json({ message: 'Login successful', user: { username: user.username, role: user.role } });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

export default router;
