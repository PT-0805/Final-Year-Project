import express from 'express';
import bcrypt from 'bcrypt';
import User from '../models/user.js'; // Adjust the path to your User model

const router = express.Router();

// Get profile information
router.get('/', async (req, res) => {
    try {
        const userId = req.user.id; // Assuming you have user ID in the request object
        const user = await User.findByPk(userId);
        if (user) {
            res.json({
                username: user.username,
                email: user.email,
                role: user.role
            });
        } else {
            res.status(404).json({ error: 'User not found' });
        }
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Update profile information
router.put('/', async (req, res) => {
    try {
        const userId = req.user.id; // Assuming you have user ID in the request object
        const { username, email, password, role } = req.body;
        const user = await User.findByPk(userId);
        if (user) {
            user.username = username;
            user.email = email;
            if (password) {
                user.password = await bcrypt.hash(password, 10); // Hash the new password if provided
            }
            user.role = role;
            await user.save();
            res.json({ message: 'Profile updated successfully' });
        } else {
            res.status(404).json({ error: 'User not found' });
        }
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

export default router;