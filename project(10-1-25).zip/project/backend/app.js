import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import sequelize from './config/db.js'; // Adjust the path to your db.js file
import userRoutes from './routes/user.js'; // Adjust the path to your routes file
import loginRoutes from './routes/login.js'; // Adjust the path to your routes file
import signupRoutes from './routes/signup.js'; // Import the sign-up route
import cartRoutes from './routes/cart.js';
import wishlistRoutes from './routes/wishlist.js';
import profileRoutes from './routes/profile.js'; // Import the profile route

const app = express();
const PORT = process.env.PORT || 3307;

// Middleware to parse JSON data
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static frontend files
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
app.use(express.static(path.join(__dirname, "../frontend")));

// Serve the index.html file for the root URL
app.get("/", (req, res) => {
  const indexPath = path.join(__dirname, "../frontend", "index.html");
  res.sendFile(indexPath, (err) => {
    if (err) {
      console.error("Error sending index.html:", err);
      res.status(500).send("Error sending file");
    }
  });
});

// Use routes
app.use('/users', userRoutes);
app.use('/login', loginRoutes);
app.use('/signup', signupRoutes); // Use the sign-up route
app.use("/cart", cartRoutes);
app.use("/wishlist", wishlistRoutes);
app.use("/profile", profileRoutes); // Use the profile route

// Test the database connection
sequelize.authenticate()
  .then(() => {
    console.log('Database connected...');
  })
  .catch(err => {
    console.error('Unable to connect to the database:', err);
  });

// Sync the models with the database
sequelize.sync()
  .then(() => {
    console.log('Models synchronized with the database.');
  })
  .catch(err => {
    console.error('Error synchronizing models with the database:', err);
  });

app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
