import { Sequelize } from 'sequelize';

const sequelize = new Sequelize('finalproject', 'root', 'Bakwaas@2105', {
    host: '127.0.0.1',
    dialect: 'mysql', // Specifies MySQL as the database dialect
    logging: false, // Disable logging SQL queries to the console
    pool: {
        max: 10, // Maximum number of connections
        min: 0, // Minimum number of connections
        acquire: 10000, // The maximum time (ms) to acquire a connection
        idle: 10000, // The maximum time (ms) a connection can be idle
    },
    define: {
        timestamps: false
    }
});

// Test the connection
(async () => {
    try {
        await sequelize.authenticate();
        console.log('Database connected.');
    } catch (error) {
        console.error('Database connection error:', error);
    }
})();

export default sequelize;