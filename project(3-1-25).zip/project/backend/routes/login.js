const express = require('express');
const router = express.Router();
const db = require('../config/db');

// ...existing code...

router.post('/login', (req, res) => {
    const { username, password } = req.body;
    // ...existing code to authenticate user...

    // Assuming user is authenticated
    const loginTime = new Date();
    const query = 'INSERT INTO login_details (username, login_time) VALUES (?, ?)';
    db.query(query, [username, loginTime], (err, result) => {
        if (err) {
            console.error('Error saving login details:', err);
            return res.status(500).send('Internal server error');
        }
        res.send('Login successful');
    });
});

// ...existing code...

module.exports = router;
