// filepath: /c:/final_year_project/project/backend/app.js
const express = require("express");
const mysql = require("mysql");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3307; // Change the port number here

// Middleware to parse JSON data
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Create a MySQL connection
const connection = mysql.createConnection({
  host: '127.0.0.1', // Replace 'localhost' with the actual hostname or IP address
  user: 'root', // Replace with your MySQL username
  password: 'Bakwaas@2105', // Replace with your MySQL password
  database: 'Crafted Wishes', // Replace with your MySQL database name
  port: 3307
});

// Connect to MySQL
connection.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL:', err);
    return;
  }
  console.log('Connected to MySQL');
});

// Serve static frontend files
app.use(express.static(path.join(__dirname, "../frontend")));

// Serve the index.html file for the root URL
app.get("/", (req, res) => {
  const indexPath = path.join(__dirname, "../frontend", "index.html");
  res.sendFile(indexPath, (err) => {
    if (err) {
      console.error("Error sending index.html:", err);
      res.status(500).send("Error sending file");
    }
  });
});

// API Route Example
app.post("/api/login", (req, res) => {
  const { username, password } = req.body;

  // Add your backend logic to authenticate users here
  if (username === "user" && password === "pass") {
    res.status(200).json({ message: "Login successful!" });
  } else {
    res.status(401).json({ message: "Invalid credentials!" });
  }
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});