// server.js
const express = require('express');
const mysql = require('mysql');
const bcrypt = require('bcrypt');
const bodyParser = require('body-parser');

const app = express();
app.use(bodyParser.json());

// MySQL Connection
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'your_password',
    database: 'crafted_wishes'
});

db.connect(err => {
    if (err) throw err;
    console.log('MySQL Connected...');
});

// Start Server
app.listen(3000, () => {
    console.log('Server running on http://localhost:3307');
});

module.exports = db;
