import express from 'express';
import bcrypt from 'bcrypt';
import User from '../models/user.js'; // Adjust the path to your User model

const router = express.Router();

router.post('/', async (req, res) => {
    try {
        const { username, email, password, role } = req.body;
        const hashedPassword = await bcrypt.hash(password, 10); // Hash the password
        const newUser = await User.create({ username, email, password: hashedPassword, role });
        res.status(201).json({ message: 'User created successfully' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

export default router;