import express from 'express';
import bcrypt from 'bcrypt';
import db from '../config/db.js'; // Adjust the path to your db.js file

const router = express.Router();

router.post('/', (req, res) => {
    const { username, password } = req.body;

    // Query to find the user by username
    const query = 'SELECT * FROM users WHERE username = ?';
    db.query(query, [username], async (err, results) => {
        if (err) {
            console.error('Error fetching user:', err);
            return res.status(500).send('Internal server error');
        }

        if (results.length === 0) {
            return res.status(401).send('Invalid username or password');
        }

        const user = results[0];

        // Log the provided password and the stored hashed password for debugging
        console.log('Provided password:', password);
        console.log('Stored hashed password:', user.password);

        try {
            // Compare the provided password with the stored hashed password
            const isPasswordValid = await bcrypt.compare(password, user.password);
            if (!isPasswordValid) {
                return res.status(401).send('Invalid username or password');
            }

            // Assuming user is authenticated
            const loginTime = new Date();
            const loginQuery = 'INSERT INTO login_details (username, login_time) VALUES (?, ?)';
            db.query(loginQuery, [username, loginTime], (err, result) => {
                if (err) {
                    console.error('Error saving login details:', err);
                    return res.status(500).send('Internal server error');
                }
                res.send('Login successful');
            });
        } catch (error) {
            console.error('Error during password comparison:', error);
            return res.status(500).send('Internal server error');
        }
    });
});

export default router;
