import express from 'express';
import db from '../config/db.js'; // Adjust the path to your db.js file

const router = express.Router();

// Add to Cart
router.post('/', (req, res) => {
    const { user_id, product_id, quantity } = req.body;

    const query = 'INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, ?)';
    db.query(query, [user_id, product_id, quantity], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.status(201).json({ message: 'Item added to cart' });
    });
});

// View Cart
router.get('/:user_id', (req, res) => {
    const { user_id } = req.params;

    const query = `
        SELECT cart.cart_id, products.product_name, cart.quantity, products.price, products.image
        FROM cart
        JOIN products ON cart.product_id = products.product_id
        WHERE cart.user_id = ?`;

    db.query(query, [user_id], (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.status(200).json({ cart: results });
    });
});

export default router;
