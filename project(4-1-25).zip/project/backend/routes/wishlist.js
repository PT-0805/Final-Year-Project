// routes/wishlist.js
import express from 'express';
import db from '../config/db.js'; // Adjust the path to your db.js file
const router = express.Router();

// Add to Wishlist
router.post('/wishlist', (req, res) => {
    const { user_id, product_id } = req.body;

    const query = 'INSERT INTO wishlist (user_id, product_id) VALUES (?, ?)';
    db.query(query, [user_id, product_id], (err, result) => {
        if (err) return res.status(500).json({ error: err.message });
        res.status(201).json({ message: 'Item added to wishlist' });
    });
});

// View Wishlist
router.get('/wishlist/:user_id', (req, res) => {
    const { user_id } = req.params;

    const query = `
        SELECT wishlist.wishlist_id, products.product_name, products.price
        FROM wishlist
        JOIN products ON wishlist.product_id = products.product_id
        WHERE wishlist.user_id = ?`;

    db.query(query, [user_id], (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.status(200).json({ wishlist: results });
    });
});

export default router;
