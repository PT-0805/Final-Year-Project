const express = require("express");
const path = require("path");

const app = express();
const PORT = 3000;

// Middleware to parse JSON data
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static frontend files
app.use(express.static(path.join(__dirname, "frontend")));

// API Route Example
app.post("/api/login", (req, res) => {
  const { username, password } = req.body;

  // Add your backend logic to authenticate users here
  if (username === "user" && password === "pass") {
    res.status(200).json({ message: "Login successful!" });
  } else {
    res.status(401).json({ message: "Invalid credentials!" });
  }
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
